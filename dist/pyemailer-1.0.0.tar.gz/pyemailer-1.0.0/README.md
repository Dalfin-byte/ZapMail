# pyemailer

`pyemailer` is a simple Python library to send emails via Gmail's SMTP server. It supports plain text, HTML content, attachments, and CC/BCC fields.

## Installation

```bash
pip install pyemailer
